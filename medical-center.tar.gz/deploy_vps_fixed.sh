#!/bin/bash

# Исправленный скрипт автоматического развертывания на VPS сервер
# Автоматически подтверждает все команды

set -e

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Конфигурация сервера
VPS_IP="89.111.170.219"
VPS_USER="root"
VPS_PASSWORD="FJKH8wQwpBOobw1T"
REMOTE_DIR="/var/www/medical-center"
APP_NAME="medical-center-app"

echo -e "${GREEN}🚀 Начинаю развертывание на VPS сервер ${VPS_IP}${NC}"

# Функция для автоматического подтверждения SSH команд
sshpass_ssh() {
    sshpass -p "$VPS_PASSWORD" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$VPS_USER@$VPS_IP" "$1"
}

# Функция для автоматического подтверждения SCP команд
sshpass_scp() {
    sshpass -p "$VPS_PASSWORD" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -r "$1" "$VPS_USER@$VPS_IP:$2"
}

echo -e "${YELLOW}📦 Создаю архив проекта...${NC}"
# Исключаем текущий архив из архива
tar -czf medical-center.tar.gz --exclude=node_modules --exclude=.git --exclude=.next --exclude=medical-center.tar.gz .

echo -e "${YELLOW}🔧 Подключаюсь к серверу и устанавливаю необходимые пакеты...${NC}"

# Обновляем систему и устанавливаем необходимые пакеты
sshpass_ssh "apt update -y"
sshpass_ssh "apt install -y curl wget git nginx software-properties-common apt-transport-https ca-certificates gnupg"

# Устанавливаем Node.js 18.x (если не установлен)
sshpass_ssh "curl -fsSL https://deb.nodesource.com/setup_18.x | bash -"
sshpass_ssh "apt install -y nodejs"

# Устанавливаем PM2
sshpass_ssh "npm install -g pm2"

echo -e "${YELLOW}📁 Создаю директории на сервере...${NC}"
sshpass_ssh "mkdir -p $REMOTE_DIR"
sshpass_ssh "mkdir -p /var/log/medical-center"

echo -e "${YELLOW}📤 Загружаю файлы на сервер...${NC}"
sshpass_scp "medical-center.tar.gz" "$REMOTE_DIR/"

echo -e "${YELLOW}📂 Распаковываю проект на сервере...${NC}"
sshpass_ssh "cd $REMOTE_DIR && tar -xzf medical-center.tar.gz --strip-components=1"
sshpass_ssh "cd $REMOTE_DIR && rm medical-center.tar.gz"

echo -e "${YELLOW}📦 Устанавливаю зависимости...${NC}"
sshpass_ssh "cd $REMOTE_DIR && npm install"

echo -e "${YELLOW}🔨 Собираю проект с упрощенной конфигурацией...${NC}"
# Используем упрощенную конфигурацию Next.js
sshpass_ssh "cd $REMOTE_DIR && cp next.config.production.js next.config.js"
sshpass_ssh "cd $REMOTE_DIR && npm run build"

echo -e "${YELLOW}⚙️ Настраиваю PM2...${NC}"
sshpass_ssh "cd $REMOTE_DIR && pm2 stop $APP_NAME 2>/dev/null || true"
sshpass_ssh "cd $REMOTE_DIR && pm2 delete $APP_NAME 2>/dev/null || true"
sshpass_ssh "cd $REMOTE_DIR && pm2 start ecosystem.config.js --env production"
sshpass_ssh "pm2 save"
sshpass_ssh "pm2 startup"

echo -e "${YELLOW}🌐 Настраиваю Nginx...${NC}"

# Создаем конфигурацию Nginx
sshpass_ssh "cat > /etc/nginx/sites-available/medical-center << 'EOF'
server {
    listen 80;
    server_name $VPS_IP;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    location /_next/static {
        alias $REMOTE_DIR/.next/static;
        expires 365d;
        access_log off;
    }
    
    location /static {
        alias $REMOTE_DIR/public;
        expires 365d;
        access_log off;
    }
}
EOF"

# Активируем сайт
sshpass_ssh "ln -sf /etc/nginx/sites-available/medical-center /etc/nginx/sites-enabled/"
sshpass_ssh "rm -f /etc/nginx/sites-enabled/default"
sshpass_ssh "nginx -t"
sshpass_ssh "systemctl restart nginx"
sshpass_ssh "systemctl enable nginx"

echo -e "${YELLOW}🔥 Настраиваю firewall...${NC}"
sshpass_ssh "ufw allow 22/tcp"
sshpass_ssh "ufw allow 80/tcp"
sshpass_ssh "ufw allow 443/tcp"
sshpass_ssh "ufw --force enable"

echo -e "${YELLOW}🔒 Устанавливаю Certbot для SSL...${NC}"
sshpass_ssh "apt install -y certbot python3-certbot-nginx"

echo -e "${GREEN}✅ Развертывание завершено!${NC}"
echo -e "${GREEN}🌐 Сайт доступен по адресу: http://$VPS_IP${NC}"
echo -e "${GREEN}📊 PM2 статус:${NC}"
sshpass_ssh "pm2 status"

echo -e "${GREEN}📝 Логи приложения:${NC}"
sshpass_ssh "pm2 logs $APP_NAME --lines 10"

echo -e "${GREEN}🔧 Полезные команды:${NC}"
echo -e "${YELLOW}Перезапуск приложения: pm2 restart $APP_NAME${NC}"
echo -e "${YELLOW}Просмотр логов: pm2 logs $APP_NAME${NC}"
echo -e "${YELLOW}Статус: pm2 status${NC}"
echo -e "${YELLOW}Перезапуск Nginx: systemctl restart nginx${NC}"

# Очищаем локальный архив
rm -f medical-center.tar.gz
