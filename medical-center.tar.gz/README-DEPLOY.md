# 🚀 Развертывание сайта на VPS сервер

## 📋 Требования

- VPS сервер с Ubuntu/Debian
- Доступ по SSH (root)
- Интернет соединение для загрузки пакетов

## 🔑 Данные для подключения

- **IP адрес:** 89.111.170.219
- **Пользователь:** root
- **Пароль:** FJKH8wQwpBOobw1T

## 🛠️ Подготовка локальной машины

### 1. Установка sshpass

Для автоматического ввода пароля установите sshpass:

```bash
# На macOS
chmod +x install_sshpass.sh
./install_sshpass.sh

# Или вручную
brew install sshpass
```

### 2. Проверка установки

```bash
sshpass -V
```

## 🚀 Развертывание

### Вариант 1: Полное развертывание (рекомендуется для первого раза)

```bash
chmod +x deploy_vps.sh
./deploy_vps.sh
```

Этот скрипт:
- Установит все необходимые пакеты (Node.js, PM2, Nginx, Docker)
- Настроит firewall
- Развернет приложение
- Настроит Nginx как reverse proxy
- Настроит PM2 для управления процессом

### Вариант 2: Быстрое развертывание

Если пакеты уже установлены:

```bash
chmod +x simple_deploy.sh
./simple_deploy.sh
```

## 📁 Структура на сервере

После развертывания файлы будут находиться в:
```
/var/www/medical-center/
├── src/
├── public/
├── package.json
├── ecosystem.config.js
└── .next/
```

## 🌐 Доступ к сайту

После успешного развертывания сайт будет доступен по адресу:
- **HTTP:** http://89.111.170.219
- **Порт:** 80 (через Nginx)

## 🔧 Управление приложением

### PM2 команды

```bash
# Подключение к серверу
ssh root@89.111.170.219

# Статус приложения
pm2 status

# Перезапуск
pm2 restart medical-center-app

# Логи
pm2 logs medical-center-app

# Остановка
pm2 stop medical-center-app
```

### Nginx команды

```bash
# Проверка конфигурации
nginx -t

# Перезапуск
systemctl restart nginx

# Статус
systemctl status nginx
```

## 📊 Мониторинг

### Логи приложения
```bash
pm2 logs medical-center-app --lines 100
```

### Логи Nginx
```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Системные ресурсы
```bash
htop
df -h
free -h
```

## 🔒 Безопасность

- Firewall настроен автоматически (порты 22, 80, 443)
- SSH доступ только по паролю
- Приложение работает за Nginx reverse proxy

## 🚨 Устранение неполадок

### Приложение не запускается

```bash
# Проверьте логи
pm2 logs medical-center-app

# Проверьте статус
pm2 status

# Перезапустите
pm2 restart medical-center-app
```

### Nginx не работает

```bash
# Проверьте конфигурацию
nginx -t

# Проверьте статус
systemctl status nginx

# Перезапустите
systemctl restart nginx
```

### Проблемы с портами

```bash
# Проверьте открытые порты
netstat -tlnp

# Проверьте firewall
ufw status
```

## 📝 Обновление приложения

Для обновления приложения просто запустите скрипт развертывания снова:

```bash
./simple_deploy.sh
```

## 🔄 Автоматическое развертывание

Можно настроить автоматическое развертывание через GitHub Actions или cron:

```bash
# Добавить в crontab для ежедневного обновления
0 2 * * * /path/to/simple_deploy.sh
```

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи приложения и Nginx
2. Убедитесь, что все порты открыты
3. Проверьте статус сервисов
4. Перезапустите приложение и Nginx
