#!/bin/bash

# Скрипт установки sshpass для автоматического ввода пароля

echo "🔧 Устанавливаю sshpass для автоматического ввода пароля..."

# Определяем операционную систему
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    if command -v apt-get &> /dev/null; then
        echo "📦 Устанавливаю sshpass через apt (Ubuntu/Debian)..."
        sudo apt-get update
        sudo apt-get install -y sshpass
    elif command -v yum &> /dev/null; then
        echo "📦 Устанавливаю sshpass через yum (CentOS/RHEL)..."
        sudo yum install -y sshpass
    elif command -v dnf &> /dev/null; then
        echo "📦 Устанавливаю sshpass через dnf (Fedora)..."
        sudo dnf install -y sshpass
    else
        echo "❌ Не удалось определить пакетный менеджер. Установите sshpass вручную."
        exit 1
    fi
elif [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    if command -v brew &> /dev/null; then
        echo "🍺 Устанавливаю sshpass через Homebrew..."
        brew install sshpass
    else
        echo "❌ Homebrew не установлен. Установите его или sshpass вручную."
        echo "💡 Для установки Homebrew выполните: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        exit 1
    fi
else
    echo "❌ Неподдерживаемая операционная система: $OSTYPE"
    echo "💡 Установите sshpass вручную для вашей ОС"
    exit 1
fi

# Проверяем установку
if command -v sshpass &> /dev/null; then
    echo "✅ sshpass успешно установлен!"
    echo "📋 Версия: $(sshpass -V)"
else
    echo "❌ Установка sshpass не удалась"
    exit 1
fi
