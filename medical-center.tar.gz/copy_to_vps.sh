#!/bin/bash
sshpass -p "FJKH8wQwpBOobw1T" scp -o StrictHostKeyChecking=no medical-center.tar.gz root@89.111.170.219:/var/www/medical-center/
